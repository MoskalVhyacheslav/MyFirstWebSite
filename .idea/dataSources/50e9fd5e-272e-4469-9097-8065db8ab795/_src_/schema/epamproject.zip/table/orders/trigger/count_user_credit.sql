CREATE TRIGGER count_user_credit
AFTER UPDATE ON orders
FOR EACH ROW
  BEGIN

    UPDATE users c
      INNER JOIN (SELECT
                    user_id,
                    SUM(credit) AS total
                  FROM orders
                  GROUP BY user_id
                 ) x ON c.user_id = x.user_id
    SET c.credit = x.total;
  END;
